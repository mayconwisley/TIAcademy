/*
    Desenvolva um algoritmo que receba três números. O algoritmo deve imprimir
    "Condição satisfeita", na tela, caso o primeiro dado inserido seja maior do que os outros
    dois (o primeiro não pode ser igual a nenhum). Caso contrário, deve ser impressa a
    mensagem: "Erro".
*/

var n1 = parseFloat(prompt("Digite um valor 1º"));
var n2 = parseFloat(prompt("Digite um valor 2º"));
var n3 = parseFloat(prompt("Digite um valor 3º"));

if (n1 > n2 && n1.n3) {
    console.log("Satisfeito");
}
else {
    console.log("Erro");
}