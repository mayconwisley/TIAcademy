/*
    12) (Adaptado de ASCENCIO e CAMPOS, 2008) Faça um programa que receba quatro
    valores, I, A, B e C. I é um valor inteiro e positivo e A, B e C são valores reais e distintos.
    Escreva os números A, B e C obedecendo à tabela a seguir. Supor que o valor digitado
    para I seja sempre um valor válido, ou seja, 1, 2 ou 3.
    Valor de I      Forma de escrever
    1               A, B e C em ordem crescente
    2               A, B e C em ordem decrescente
    3               O maior fica entre os outros dois números
*/

document.write("Pacote de Exercicio 03 - Exercicio 12");
console.log("Pacote de Exercicio 03 - Exercicio 12");
document.write("<br>");
document.write("<br>");