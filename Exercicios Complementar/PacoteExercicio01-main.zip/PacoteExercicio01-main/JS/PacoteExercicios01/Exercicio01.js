/*
  (Adaptado de ASCENCIO e CAMPOS, 2008) Faça um programa que receba quatro
    números inteiros, calcule e mostre a soma desses números.
 */
document.write("Pacote de Exercicio 01 - Exercicio 01");
document.write("<br>");
document.write("<br>");
console.log("Pacote de Exercicio 01 - Exercicio 01");

var numero = 0;
numero += parseInt(prompt("Digite o 1º numero"));
numero += parseInt(prompt("Digite o 2º numero"));
numero += parseInt(prompt("Digite o 3º numero"));
numero += parseInt(prompt("Digite o 4º numero"));

document.write("A Soma dos numeros são: " + numero);
console.log("A Soma dos numeros são: " + numero);